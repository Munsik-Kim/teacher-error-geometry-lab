# Frozen P0/P1 protocol

Scope: local CPU independent implementation of the two-dimensional special case
in docs/theory.md. P1 full is exactly configs/p1.json: c=.5, R=2000, 50 A,
10 B, and 24 C cells. A/B/C fit denominators are 100000/20000/48000;
unique dataset denominators A=50000,C=12000,B additional=0. B refers to 20000
A datasets; rho=0 B/hidden are the same target and are not independent evidence.

Use FP64 np.linalg.lstsq with rcond=None, one target per call, no intercept,
ridge, clipping, jitter, whitening, normalization of sampled data, or filtering.
The solver takes only Z,T. Data generation and evaluation can know the model.
Every fit's population risk is evaluated analytically using its fitted w;
the expectation over training samples is a separate function. No full-run
evaluation dataset is generated.

## RNG and order

PCG64(SeedSequence([2026102101,stream,block,rho_index,n_index,replicate])).
Stream data=0, independent test-risk check=1, bootstrap=2 reserved and unused.
Data block A/B=0,C=1,P0 diagnostics=2. Indices are zero-based config list
order; teacher ID is absent. Each key directly seeds a new Generator. Draw
standard_normal((2,n),dtype=float64), first row X1, second U. Then construct
X2. No teacher-noise RNG exists. Dataset IDs are d{block}_r{ri}_n{ni}_rep{rep}.
B uses A's actual in-memory X and A's rho/n indices, including n_index=1 or3.
Replicate IDs in different rho/n groups refer to independent datasets.

Loop A rho,n,replicate,visible/hidden/B-if-applicable, then C rho,n,replicate,
theta. Serial batches of 200, bounded streaming CSV output, no subprocess
parallelism. Each dataset is recreated by its own seed, independent of batch
size/order. Restart means a fresh output directory with the same config; no
automatic overwrite or cherry-picked cell rerun is implemented.

## P0 gate, freeze and resource budget

Required controls are encoded in tests/test_contract.py and independent P0
test Monte Carlo in checks.py. The latter uses three fixed fitted models and
100000 independent test cases each, checks six risks against 6 sample MC-SE
(a deterministic zero uses tolerance), and has one separate covariance smoke
diagnostic. It does not certify population covariance from a finite sample.
The smoke command also runs 20 repeats in every cell (1680 fits,620 datasets)
to measure cost. This pilot is labelled NOT-FULL. Batch size200 is fixed after
that resource check; at most one n<=1000 dataset and its targets are resident.
P0 unit-test solver calls are not instrumented in aggregate; P1 calls and
verification replay calls are counted separately.

Before full data, freeze config, this protocol, theory/claim/source-access docs,
environment, every src/test/script file, and config/build specifications.
Each entry has bytes/SHA256 and a copied source snapshot. Bundle identity is
SHA256(canonical sorted manifest JSON); config has its own SHA256. Capture
actual start UTC, Git commit/status, and per-process environment. A local commit
is supplementary; the bundle plus config identifies execution. Later reports
are documentation changes, not retrospective execution-source changes.
Never modify full-run science/config in place; preserve its run and use a new
run ID after any change. Outputs must not exist when a command creates them.

Full run's wall cap7200s is checked at each batch boundary. Resource or budget
stop preserves partial raw and PARTIAL status with reason and actual counts.
No reduced run can be labelled full COMPLETE. Each invocation sets BLAS threads
to1 in its child environment only. No GPU, model/download, paid API, remote
repository, push, PR, Pages, or inference-lab integration is part of this task.

## Metrics and diagnostic rules (fixed before full)

Deterministic FP64 tolerance: atol=1e-10,rtol=1e-9. Nondegenerate sample SD
uses ddof=1, MC-SE=SD/sqrt(N_valid), pointwise normal95% interval=mean+-1.96SE.
Report mean-theory and (mean-theory)/SE. Deterministic cells use per-row tolerance
and no z score. Zero SE never gets divided. Flag |z|>4 for investigation, not
automatic scientific failure; 95% inclusion in every cell is not a pass rule.
Flag paired comparisons too; dependencies and repeated metrics prevent treating
these as independent trials. Do not change tolerance or drop failures afterward.
Recognize exact paired-risk degeneracy algebraically: teacher risk depends on
b^2; at rho0 the normalized theta and pi-theta loadings coincide. Shared-data
truth-risk differences are deterministic when their Q and Q^2 coefficients
both vanish. Check these per-row identities with the same frozen tolerance.

Preserve every abnormal row; record its status,error,rank. Summary separates
R_planned,R_rows,N_valid,N_failed,N_missing. Failed and nonfinite rows are
excluded from finite means only with those denominators displayed. Pairwise SE
comes from the vector of differences on shared replicate/dataset keys. Two
risks of one fit are not two observations. B is not independent replication.
execution_status,implementation_verification,statistical_comparison and
publication_readiness must be reported separately.

Plot plan: 01 truth risk by n (5 rho panels); 02 hidden and paired projection-zero
truth risk by rho (n30/300) with population floors; 03 truth and teacher-agreement
MSE side-by-side at rho0; 04 exact3rho x4theta x2n C heatmap (24 cells), with
analytic and MC panels; 05 normalized eta relation. Save PNG and SVG. Lines are
theory; markers/pointwise95% error bars are MC. The heatmap has actual axes,
and Euclidean ||delta|| is distinct from population teacher error.

## Raw schema and replay

CSV UTF-8, header present, Python shortest round-trip FP64 decimals; no pickle.
raw/datasets.csv is the seed/hash reference table. Columns: dataset_key,
data_block,rho_index,n_index,replicate,rho,n; seed_root,seed_stream,seed_block,
seed_rho,seed_n,seed_replicate; data_sha256,status,error. Hash concatenates
X1,U,X2 in that order, each little-endian float64 C-order bytes, no header.

raw/d{block}_r{ri}_n{ni}.csv stores each fitted-student row:
row_key,config_id,block,teacher,rho,n,c,theta,replicate,dataset_key,delta1,delta2,
a,b,teacher_mse,eta,w,truth_risk,teacher_risk,rank,status,error.
row_key=config_id+':rep'+replicate is unique. Blank theta means not applicable;
blank eta means zero error; failed numerical values are textual nan with status.
Exact dimensions and teacher definitions are in provenance/cells.json.

summary/cells.csv has two metric rows per cell; paired_differences.csv includes
left-minus-right means and paired SEs; failures.csv retains abnormal records;
overview.json holds frozen config, diagnostic statuses and all flagged rows.
The verifier checks hashes, all raw keys/coverage/metadata, risk identities,
rho0 reuse, then regenerates12 fixed datasets (4 replicates in first/middle/last
groups) and their coefficients/risks plus scalar-solver identities. It never
reruns the full sweep. Raw-to-summary and figure regeneration must use new
output paths and compare core numbers. Figure byte equality is also checked
in the recorded environment; rendering portability is a narrower guarantee.

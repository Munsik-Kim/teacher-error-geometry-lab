# Claim map and evidence boundary

| Claim | Implementation/evidence | Status before full |
| --- | --- | --- |
| Gaussian covariance by construction | model.generate, direct algebra in theory.md | Implemented; P0 gate pending |
| OLS learner sees only Z,T | solver.fit_student signature; scalar check | Implemented; P0 gate pending |
| E truth=a^2+b^2/(n-2) | independent direct derivation; theory.expectation | Paper correspondence READ; P1 comparison pending |
| Projection-zero removes population bias | Corollary4.5 correspondence; B vs paired A | P1 comparison pending |
| Teacher agreement differs from truth risk | quadratic evaluator; separate expectations and plot03 | P1 comparison pending |
| Normalized-angle relation | 24 C cells, eta curve and heatmap | P1 comparison pending |
| Gold-target noiseless control has risk0 | separate P0 control | P0 gate pending |
| Source/config/version frozen before full | provenance/freeze.json, source copies, local Git or bundle hash | Created at run start |

This document freezes the intended claims; post-run results and statuses belong
to P1_REPORT.md and P1_REPORT.ko.md. It does not get retroactively rewritten to
make the pre-run plan look verified.

Paper source: [Sudjianto and Burakov, v1 §4.2](https://arxiv.org/html/2610.26797v1#S4.SS2).
The teacher-agreement formula is a direct independent calculation here. P1 is a
2D special case, not the paper's Table1 experiment or a complete paper validation.
No novelty, performance improvement, LLM law, quantization, or serving claim is
made. Agreement is evidence of formula/code consistency under this exact model.

P2 roadmap ONLY: Table1 d5/r3/n27, full outcome/full teacher/representation
outcome/representation mixed,20000 repeats; original-setting comparison and
later correlation-change/non-Gaussian/LLM work. No P2 implementation or execution
is authorized in this run. Constant-rho independent cells in P1 are not a
train/test correlation-shift experiment.

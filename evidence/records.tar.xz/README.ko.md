# Teacher Error Geometry Lab

논문 해석식과 실제 반복 OLS 학습 위험을 대조한 로컬 CPU 재현 포트폴리오다.
[English](README.md). 현재 **LOCAL_ONLY**이며 원격 게시하지 않았다.

P1:독립2D 특수형84셀×2000회,168000fit/고유dataset62000,기존 검사17개.
P2:원문 Table1 Gaussian d5/r3/n27,lambda.45 한 점,공통dataset20000/fit80000.
새 검사12개와 기존 P1 검사17개의1회 회귀 검사 PASS다. 두 단계 full 실패·누락0,
P1 보호340파일은 그대로다. [P1 보고서](docs/P1_REPORT.ko.md) ·
[P2 보고서](docs/P2_REPORT.ko.md) · [단계 이력](docs/P2_RUN_HISTORY.md).

| P2 방식 | 이론값 | MC 평균 | MC-SE | z |
| --- | ---: | ---: | ---: | ---: |
| FO | 0.3095238095 | 0.3101549484 | 0.001636764018 | 0.3856016026 |
| FT | 0.4044666667 | 0.4038669197 | 0.001518421967 | -0.3949804327 |
| RO | 0.26 | 0.2598640016 | 0.001152661475 | -0.1179863825 |
| RM | 0.2068751522 | 0.2076789594 | 0.0007907319008 | 1.016535782 |

네 방식·여섯 paired 차이에 >4SE flag가 없다. RM의 표본 교차항 평균
+.000411069841을 기대값0으로 바꾸지 않고 보존했다.

![P2 원문 고정 설정의 네 위험](runs/p2_paper_anchor_20261021T065112Z/figures/01_four_methods_truth_risk.png)

[원문 v1 Lemma3.1·Proposition3.2·Proposition4.1·Theorem4.3·Table1](https://arxiv.org/html/2610.26797v1)을
직접 대응했다. 저자 코드는 복사하지 않았다. NumPy CPU와 원문 PyTorch 난수는
다르며 기대 위험의 부분 재현이다. 원문 표본·논문 전체의 재현이 아니다.
[원문 대응](docs/P2_SOURCE_MAP.ko.md) · [P2 프로토콜·schema](docs/P2_PROTOCOL.md).

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
./scripts/teg p2 verify --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-verify-NEW_ID.json
./scripts/teg p2 summarize --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-rebuild-NEW_ID/summary
./scripts/teg p2 figures --summary /tmp/teg-p2-rebuild-NEW_ID/summary --output /tmp/teg-p2-rebuild-NEW_ID/figures
```

출력은 새 경로여야 한다. Wrapper가 PYTHONPATH=src,Agg,프로젝트 cache,자식 BLAS
thread1을 설정한다. 기존 attention Python 또는 TEG_PYTHON을 사용한다.
[전체 명령·의존성·P1 보존법](docs/reproduce.md).
P2 full runner5.903초. [동결 source/config hash](runs/p2_paper_anchor_20261021T065112Z/provenance/freeze.json).
P1 보고서와 과거 명령은 당시 기록이며 원 receipt를 덮어쓰지 않는다.

P3 문서·깨끗한 환경 재현·공개 준비는 후속이다. n/lambda sweep,비Gaussian,상관shift,
probit,실제 LLM,CFPB로 확대하지 않았다. GPU·모델·다운로드·유료API·설치업그레이드·
원격게시0. 내부 AI 보조 검사이며 사람 독립 심사는 아니다. 독립 작성물만 MIT이며
원문·타인 권리는 [NOTICE](NOTICE)에서 분리한다.

# P1 보고서 — Teacher Error Geometry Lab

2026-10-21 KST. 최종 run은 `p1_full_20261021_02`이다. 로컬 CPU P0/P1 구현·실행을 완료했다.
독립 구현한 2차원 Gaussian 특수형의 반복 결과가 동결한 판정 기준에서 해석식과
일치했다. 재현 포트폴리오 산출물이며 새 알고리즘이나 논문 전체 재현을 뜻하지 않는다.

| Field | Value |
| --- | --- |
| execution_status | COMPLETE |
| implementation_verification | PASS |
| statistical_comparison | NO_4SE_FLAGS |
| publication_readiness | LOCAL_CANDIDATE_READY |
| paper_correspondence | READ_AND_MAPPED_SPECIAL_CASE_ONLY |

## 범위·실행 버전·방법

작업경로: `/home/mskim/Codex_main/teacher-error-geometry-lab`. 실행 commit: `df1173e91e77a43a53e9a82beea079c65bd0dab6`.
Source bundle SHA256: `286b7639b3abfb69503926dad32f35dc27ddd11356a8a15fe2b72377e37716a2`.
동결 config SHA256: `f909d298b234af6a3a1a4175066004bd203d91d0ac9912cb34271e058551a11b`.
실제 시작 UTC: `2026-10-21T06:03:10.472950+00:00` (2026-10-21 15:03:10 KST).
동결 시 미추적 경로는 새 run 디렉터리뿐이었고 실행 소스는 commit 상태였다.
보고서·재생성 검증 metadata는 실행 뒤 작성했으며 동결한 과학 소스는 바꾸지 않았다.
파일별 bytes/SHA256·복사본은 [freeze.json](../runs/p1_full_20261021_02/provenance/freeze.json)에 있다.

[원문 v1 §4.2 Theorem 4.3·Corollary 4.5](https://arxiv.org/html/2610.26797v1#S4.SS2)를
직접 읽었다. 대응은 A=[1,0],beta=(1,0),gamma=beta+delta,r=1,lambda=1,
추가 잡음0,B_A=0,D_A=a²,G_A=b²이다. [직접 유도](theory.md)와
[접근 기록](source_access.md)을 남겼다. 저자 코드는 열람·복사하지 않았다.

독립 X1,U에서 X2=rho*X1+sqrt(1-rho²)*U를 생성했다. 학생 solver의 입력은
Z=X1,T뿐이다. 절편·규제 없는 FP64 np.linalg.lstsq를 target마다 한 번 호출했다.
각 fitted w의 population risk는 quadratic form으로 평가하고, 학습 표본 재생성
기대값은 별도 함수에서 계산했다. 학습 MSE 대체·반복마다 큰 평가셋·whitening·
유한 표본 covariance 강제 조정은 사용하지 않았다.

## 계획·실제 분모와 비용

| Block | Cells | Planned / actual fitted rows | New datasets | Reused A references |
| --- | ---: | ---: | ---: | ---: |
| A | 50 | 100000 / 100000 | 50000 | 0 |
| B | 10 | 20000 / 20000 | 0 | 20000 |
| C | 24 | 48000 / 48000 | 12000 | 0 |
| Total | 84 | 168000 / 168000 | 62000 | 20000 |

모든 셀에서 R_planned=R_rows=N_valid=2000이고 N_failed=N_missing=0이다.
실제 fit object168000,solver 호출168000,고유 dataset 생성62000회다.
B는 A의 실제 X를 재사용해 추가 fit한다. rho0의 B와 hidden은 같은 target이므로
독립 재현 증거가 아니다. 같은 fit의 truth/teacher risk도 독립 관측으로 더하지 않는다.

| 단계 | Wall 초 | CPU 초 | Peak RSS MiB |
| --- | ---: | ---: | ---: |
| P1 experiment (runner) | 9.240 | 9.238 | 55.20 |
| summary | 1.64 | 1.62 | 370.88 |
| figures | 2.56 | 2.49 | 124.70 |
| verify | 14.49 | 14.45 | 158.34 |
| rebuild_summary | 1.62 | 1.60 | 371.02 |
| rebuild_figures | 2.46 | 2.49 | 127.03 |

Runner 시간은 동결 준비·순차 실험부터 최종 execution snapshot까지의 계측값이다.
CLI 시작·마지막 raw-manifest hash 계산은 내부 타이머 밖이다. 다른 단계는
/usr/bin/time으로 측정했다. 배치200,자식 BLAS thread1,상한7200초이며 자원 중단은
없었다. Raw CSV는 43482396bytes(41.47MiB)다.
최대 메모리는 fit보다 summary 로딩 단계에서 발생했다. 최종 P0 검사17개와
고정 fitted model3개의 독립 test-MC risk6개가 통과했다(모델당 test100000개).
Covariance 검사는 별도 smoke 진단이다. P0 pilot은 셀당20회,1680fit,620dataset,
0.107초였고 P0 전체 peak RSS는 70.73MiB였다.

환경은 Python3.11.15,NumPy1.26.4,Matplotlib3.10.9,AMD Ryzen7 9800X3D,
WSL2 Linux5.15.167.4다. NumPy build 설정은 OpenBLAS64 0.3.23.dev로 기록됐다.
[환경 원본](../runs/p1_full_20261021_02/provenance/environment.json)에 정확한 Python·OS·BLAS·
thread 변수를 남겼다. 기존 CPU 환경을 읽기 전용으로 사용했고 설치·업그레이드는0이다.

## 관측값과 해석

아래는 모두 실제 R=2000 결과다. 결정적 대조의 FP64 잔차도 그대로 남겼다.
뒤의 설명용 예측은 별도의 해석값이다.

| 셀 (rho,n) | 지표 | MC 평균 | MC-SE | Pointwise 95% 구간 | 이론값 | z 또는 규칙 |
| --- | --- | ---: | ---: | --- | ---: | --- |
| A_r2_n1_axis_visible (0.0,30) | truth_risk | 0.25 | 8.655496233e-18 | [0.25, 0.25] | 0.25 | tolerance |
| A_r2_n1_axis_visible (0.0,30) | teacher_risk | 1.497603125e-31 | 4.840661328e-33 | [1.402726163e-31, 1.592480087e-31] | 0 | tolerance |
| A_r2_n1_axis_hidden (0.0,30) | truth_risk | 0.008460831453 | 0.0002714734544 | [0.007928743482, 0.008992919423] | 0.008928571429 | -1.722967636 |
| A_r2_n1_axis_hidden (0.0,30) | teacher_risk | 0.2584608315 | 0.0002714734544 | [0.2579287435, 0.2589929194] | 0.2589285714 | -1.722967636 |
| A_r2_n3_axis_hidden (0.0,300) | truth_risk | 0.0008330708234 | 2.615235311e-05 | [0.0007818122113, 0.0008843294355] | 0.0008389261745 | -0.2238938512 |
| A_r2_n3_axis_hidden (0.0,300) | teacher_risk | 0.2508330708 | 2.615235311e-05 | [0.2507818122, 0.2508843294] | 0.2508389262 | -0.2238938512 |
| A_r4_n4_axis_hidden (0.9,1000) | truth_risk | 0.2025503873 | 0.000141711919 | [0.2022726319, 0.2028281427] | 0.2025475952 | 0.01970273619 |
| A_r4_n4_axis_hidden (0.9,1000) | teacher_risk | 0.04754944931 | 1.547725884e-06 | [0.04754641576, 0.04755248285] | 0.04754759519 | 1.197961281 |
| B_r4_n1_projection_zero (0.9,30) | truth_risk | 0.008805482068 | 0.0002880140519 | [0.008240974526, 0.009369989609] | 0.008928571429 | -0.4273727626 |
| B_r4_n1_projection_zero (0.9,30) | teacher_risk | 0.2588054821 | 0.0002880140519 | [0.2582409745, 0.2593699896] | 0.2589285714 | -0.4273727626 |
| C_r1_n1_t2 (0.0,300) | truth_risk | 0.0007675668765 | 2.357325768e-05 | [0.0007213632915, 0.0008137704616] | 0.0008389261745 | -3.027129256 |
| C_r1_n1_t2 (0.0,300) | teacher_risk | 0.2507675669 | 2.357325768e-05 | [0.2507213633, 0.2508137705] | 0.2508389262 | -3.027129256 |

c=.5,rho0,n30의 **해석적 예측**은 visible truth=.25,teacher0,
hidden expected truth=.25/28=.008928571428571428,expected teacher
=.25892857142857145다. 실측 hidden truth는 .00846083145254395이며 예측을
실측으로 바꿔 쓰지 않았다. Visible teacher MSE 약1.5e-31은 solver roundoff이며
결정적0 tolerance를 통과한다. 이 교사와 거의 완벽히 일치해도 truth risk는 .25다.
별도 gold-target 학생은 수학적으로 truth risk0이고 P0에서 FP64 tolerance를 통과했다.
그 정답은 교사 학습 fit에 전달하지 않았다.

B에서는 모든 rho에서 a=0,b=.5이므로 기대 truth risk는 n30에서
.008928571428571428,n300에서 .0008389261744966443이다. 유한 반복 평균은
그 주위에서 달라진다. A hidden의 무한 표본 floor는 c²rho²이며 rho.9에서는 .2025다.
n1000 실측 truth .20255038730293556은 floor에 분산 항을 더한 예측과 대응한다.
C는 정확히3rho×4theta×2n=24셀이다. Population teacher error는 모두 .25이고
Euclidean 계수 norm은 다르다. Eta 관계는 E[R_truth]/c²=eta+(1-eta)/(n-2)다.

개별 지표 요약168개는 결정적 PASS62개,WITHIN_4SE106개다.
Paired 차이 요약162개는 결정적 PASS6개,WITHIN_4SE156개다.
최대 |z|는 개별 3.027129,paired 3.027129이며
미해결 >4SE 조사 대상은0이다. 이 요약들은 서로 의존하며 추가 독립 관측이 아니다.
표본 SD는 ddof1,MC-SE=SD/sqrt(N_valid),pointwise 정규근사95% 구간은
mean±1.96SE다. 동시 보장 구간이 아니다. 일부95% 구간에는 이론값이 들어가지 않는다.
예를 들어 C rho0,n300,theta pi/2 truth의 z는 -3.027129다. 사전 조사 문턱4보다
작으며 이것을 모든 수식의 증명으로 해석하지 않는다. 결정적 대조는 반복별
atol1e-10,rtol1e-9로 검사하고 z로 나누지 않는다.

## 보존한 문제와 새 실행 버전

첫 P0의 테스트 harness 변수명 오류는 실패 기록으로 남겼다. 첫 full은
9.168초에 완료했고 raw는 올바랐다. 다만 C rho0,
theta pi/4와3pi/4의 paired teacher-risk 차이가 결정적이라는 분류를 놓쳤다.
약1.54e-17/1.65e-17의 mean-theory 차이를 z17.973973/42.247806으로 표시했다.
기존 flag·source·raw·summary를 지우지 않았다.

이 두 교사의 정확한 위험은 공통 b²,Q에 대해 b²(1+Q²)로 같다. 이 구조적 분류와
회귀 검사를 추가하고 새 P0 및 새 full run ID를 실행했다. Tolerance·생성기·solver·
risk·seed·반복 수·격자는 바꾸지 않았다. Raw32파일의 hash와 개별 cells.csv는
첫 full과 정확히 같다. Paired 진단 분류만 달라졌고 이상 셀의 seed를 교체하지 않았다.
[실행 이력](RUN_HISTORY.md)에 원래 판정도 남겼다.

비용 분모는 full2회 합계 solver336000회,dataset 재생성 event124000회다.
고유 dataset key는62000개이고 동일한2000반복을 두 번 사용했다. 두 실험 시간 합은
18.408초다. 독립4000반복으로 합산하지 않는다.
P0 unit-test solver 호출 총수는 계측하지 않았으며 위 full 분모에 넣지 않았다.
최종 verify는 고정12dataset에서 별도32solver 호출을 추가했다. 이후 summary/figure
재생성에서는 full sweep을 다시 실행하지 않았다.

## 재생성 검증·그림·실행법

Raw 전체의 무결성·고유 key·seed mapping·pairing·risk 항등식이 통과했다.
고정12dataset을 seed에서 다시 만들고 data hash·scalar/lstsq 계수·risk를 대조했다.
새 경로 `reproductions/p1_full_20261021_02_rebuild_01`에서 raw→summary→figure를
재생성했다. 비교15파일(summary4,PNG/SVG10,figure manifest1)이 현재 환경에서
byte 단위로 같았다. [검증](../runs/p1_full_20261021_02/provenance/verification.json),
[재생성 증거](../runs/p1_full_20261021_02/provenance/reproduction.json),
[최종 상태](../runs/p1_full_20261021_02/provenance/final_status.json),
[한영 공통 수치](report_facts.json)를 함께 남겼다.

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
# Existing CPU environment; wrapper sets PYTHONPATH, Agg, local cache, BLAS threads=1.
./scripts/teg verify --run runs/p1_full_20261021_02
./scripts/teg smoke --output /tmp/teg-p0-YOUR_NEW_ID
./scripts/teg summarize --run runs/p1_full_20261021_02 --output /tmp/teg-rebuild-YOUR_NEW_ID/summary
./scripts/teg figures --summary /tmp/teg-rebuild-YOUR_NEW_ID/summary --output /tmp/teg-rebuild-YOUR_NEW_ID/figures
# Optional future full rerun, not needed to inspect/rebuild the saved results.
./scripts/teg run --config configs/p1.json --output /tmp/teg-full-YOUR_NEW_ID
```

출력 생성 명령에는 존재하지 않는 새 경로가 필요하다. Wrapper는 기존 attention Python,
PYTHONPATH=src,Agg,프로젝트 cache,자식 BLAS thread1을 설정한다. TEG_PYTHON으로
호환 Python을 선택할 수 있다. 직접 module 실행·프로젝트 .venv 설치 조건은
[재현 안내](reproduce.md)에 적었다. CLI는 실제 구현됐고 wrapper 사용에는 설치가 필요 없다.

[그림 경로](../runs/p1_full_20261021_02/figures)에5종 PNG+SVG가 있다. 이론선·MC평균·pointwise
구간을 구분했다. PNG5종의 축·범례·실제 셀 수를 시각 확인했다. 이는 내부 AI 보조
점검이며 외부 심사나 다른 플랫폼의 렌더링 보장을 뜻하지 않는다.

## 남은 범위·전달

P2는 원문 Table1 d5/r3/n27,full outcome/full teacher/representation outcome/
representation mixed 네 방식,20000반복을 roadmap에만 남겼다. 구현·실행하지 않았다.
비Gaussian·학습/평가 상관 변화·probit·실제 LLM·CFPB 실험도 미실행이다.
신규성·서빙·양자화 개선을 주장하지 않는다. MIT 범위는 독립 작성물이며 LICENSE/NOTICE에
원문·타인 자료의 권리를 분리했다. GPU작업0,모델요청0,모델다운로드0,유료API0,원격게시0이다.
기존 inference-lab·Direction–Scale·serving·ComfyUI 환경을 수정하지 않았다.
로컬 공개 후보 준비는 논문 전체 검증이나 사람의 독립 심사를 뜻하지 않는다.
작은 UTF-8 인계 파일은 worktree 밖
`/home/mskim/Codex_main/handoffs/teacher_error_geometry_P0_P1_20261021.txt`에 둔다.

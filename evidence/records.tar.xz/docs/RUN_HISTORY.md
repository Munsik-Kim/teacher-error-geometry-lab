# Preserved run history

1. p0_20261021_01: harness error, not a completed gate. A Path attribute named
   run shadowed unittest.TestCase.run. Renamed it before the next attempt.
2. p0_20261021_02:16 tests PASS, independent test-MC PASS, all-cell20-repeat
   pilot complete; first full source commit c098b75895a980b2dc771a5c34e6e7562ecf2354.
3. p1_full_20261021_01:168000 rows,62000 datasets,168000 solver calls,
   9.168011801s; numerical failures0; raw/seed/risk verification PASS before
   later source changes. All168 marginal risk comparisons passed their frozen
   rules. Two symmetric paired teacher-risk comparisons were incorrectly
   treated as stochastic: C rho0,theta pi/4 minus3pi/4, n30 and300.
   z=17.9739725618 and42.2478055504 arose from mean-theory differences
   1.5376588891e-17 and1.6486811916e-17, respectively. Their absolute
   differences are negligible under the predeclared tolerance; the same-data
   identity makes them deterministic in exact arithmetic.
4. The first full raw/summary/freeze/verification are preserved unchanged.
   Fix only the paired deterministic classification and add its regression
   check and derivation. Do not change data, learner, risk evaluator, seed,
   repetitions, or tolerance. A fresh P0 gate and a new full run ID are required
   to identify the revised execution source. No selective cell rerun is used.

The original overview.json retains INVESTIGATE and both flags. Verification of
that original run was done against its then-current source; its frozen source
snapshot is the version for reproducing its old classifier. The final report
identifies the later canonical run and records both runs' cost separately.

5. Canonical p1_full_20261021_02: execution commit
   df1173e91e77a43a53e9a82beea079c65bd0dab6; source bundle
   286b7639b3abfb69503926dad32f35dc27ddd11356a8a15fe2b72377e37716a2.
   P0 tests17 PASS; full168000 rows/62000 dataset keys/168000 solver calls,
   9.239981899s. Numerical exceptions0,missing rows0; all raw verification
   and12 fixed dataset replays PASS. Marginal comparisons:62 deterministic
   plus106 within4SE; paired:6 deterministic plus156 within4SE; unresolved
   flags0. All32 raw hashes and marginal summary bytes equal the first run.
   Fresh summary/figure regeneration matches all15 compared files exactly.
   No scientific/config changes follow this canonical freeze; later changes
   are reports, delivery metadata and artifact commits only.

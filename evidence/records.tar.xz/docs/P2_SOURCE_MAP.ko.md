# P2 원문·가정·구현·검증 대응 (실행 전)

2026-10-21 KST, 과학 구현 전에 원문 HTML v1과 abstract에 직접 접근했다.
대상: Agus Sudjianto,Denis Burakov, arXiv:2610.26797v1(2026-10-19).
[원문](https://arxiv.org/html/2610.26797v1),
[버전 정보](https://arxiv.org/abs/2610.26797v1).
§3.1 Lemma3.1,§3.2 Proposition3.2,§4.1 Proposition4.1,§4.2 Theorem4.3,
§7.1 Table1을 직접 읽었다. Table1의 모든 요청 파라미터와 일치하며,
n27은 원문의 n목록 중 한 점,lambda.45는 원문의 고정 mixed-head 값이다.
원문31점 lambda sweep·전체 n축은 실행하지 않는다.

| 원문 위치 | 가정·식 | 실제 변수·경로 | 검증 |
| --- | --- | --- | --- |
| §3.1 식1-3/Lemma3.1 | 독립 Gaussian X,Sigma 양의 정부호,잡음은 X와 독립,n>d+1 | p2.model.generate; FO=(X,Y) | 일반 식과 Fraction13/42,QR·고정 model test-MC |
| §3.2 식4/Proposition3.2 | T=X gamma+xi,gamma=beta+delta | p2.model.targets; FT=(X,T) | B=.2378,6067/15000,5D fitted quadratic/좌표·FT 교차항 |
| §3.3·§4.2 | epsilon,xi 결합 Gaussian,공분산omega | noise_factor의2x2인자; E/H 독립 stream | factor@factor.T=[[1.3,.22],[.22,.7]],det=.8616; 부적합 오류 |
| §4.1 식8-9/Proposition4.1 | 고정 A full row rank,Z=AX,표현 잔차독립성 | 행 구현 Z=X@A.T; RO=(Z,Y) | solve(C,A Sigma beta),B_A=.08,13/50 |
| §4.2 식11-12/Theorem4.3 | V=(1-lambda)Y+lambda T,n>r+1,잔차결합 | RM=(Z,V); projection/expectation 별도 | D_A=.0753,G_A=.4625,S_A=.19,9516257/46000000 |
| §7.1 Table1 | d5/r3,SigmaI5,A=[I3,0],beta/delta/noise,n27,lambda.45,R20000 | configs/p2_paper_anchor.json | 원문 값 직접 대조; 네 방식 공통 dataset hash/replicate |
| §7.1의 원문 계산법 | fitted coefficient마다 test expectation 계산,학습 표본20000회 | p2.risk.fitted_risk e^T Sigma e | 좌표 분해·RM signed cross·12 key 재생성 |

일반 투영 경로 C=A Sigma A^T,w_beta=solve(C,A Sigma beta),
w_gamma=solve(C,A Sigma gamma),u_beta/u_gamma에서 B,B_A,D_A,G_A,S_A를 계산한다.
별도 scalar/Fraction 경로는 decimal 상수의 합과 유리수 산술만 사용한다.
기대값을 fitted risk로 대신하지 않는다. 주 지표는 참 신호 X beta 대비 risk이며
관측 Y의 추가 분산1.3을 더한 MSE가 아니다. RM 잔차결합 S_A+omega=.41을
독립 잡음으로 바꾸지 않는다. 기대 분해의 교차항0과 유한 표본 교차항은 구분한다.

원문은 PyTorch generator seed20261016과 GPU 실행을 기술한다. 이번 구현은
기존 NumPy CPU PCG64,별도 root2026102102를 사용한다. 같은 분포·조건·기대 위험의
부분 수치 재현이며 원문 난수·표본·MC 평균의 bitwise 복제가 아니다.
원문 §7.2의 최적 lambda 최소 위험(.2066 근사)과 이번 lambda.45의
기대값 .206875152173913...을 같은 숫자로 쓰지 않는다.

Hugging Face markdown endpoint는 web 도구에서 접근되지 않았다. 필요한 원문은
arXiv HTML에서 읽었다. Ancillary experiments.py 등의 저자 코드는 열람·복사하지
않았다. 논문 식과 가정에서 독립 구현했으며 AI 보조 수치 검산은 사람 심사·외부
실행과 구분한다. P1의 원문 접근 기록은 원형 보존하고 이 파일에 P2 접근을 추가한다.

P1의 B_A=0 특수형에서 P2는 B_A=.08 표현 손실과 S_A+omega=.41까지 범위를
진전시킨다. n축 threshold·최적 lambda·일반 증류/압축 우위·새 알고리즘은 검증하지
않는다. 상태와 최종 관측값은 별도 P2_REPORT.ko.md/P2_REPORT.md에 기록한다.

# P2 pre-full protocol: single Gaussian paper anchor

2026-10-21 KST. Independently implement one Table1 regression setting from
[arXiv:2610.26797v1 §7.1](https://arxiv.org/html/2610.26797v1#S7.SS1).
No author code is accessed. This is a distribution/parameter/expectation
reproduction, not original samples, original MC means, or the entire paper.
P1 reports, theory, source_access, RUN_HISTORY, all runs/snapshots/receipts,
rebuilds and handoff stay byte-for-byte unchanged. An initial path/bytes/SHA256
inventory in p2_preflight/20261021T063310Z/p1_before.json covers340 files,
92111045bytes. Compare at smoke, full start, verification, and final delivery.
Only the shared CLI receives a new p2 subcommand; P1 scientific modules and
test_contract.py stay unchanged. P2 tests are in tests_p2, outside P1 discovery.

## Fixed setting and information boundary

configs/p2_paper_anchor.json: d5,r3,n27,Sigma=I5,A=[I3,0],
beta=(.9,-.6,.5,.2,-.2),delta=(.22,-.13,.10,.35,-.20),gamma=beta+delta;
sigma2=1.3,tau2=.7,omega=.22,lambda=.45,R20000. Omega is covariance and
sigma2/tau2 are variances. Positive noise determinant=.8616.

Independent standard normal X,E,H give epsilon=sqrt(sigma2)*E and
xi=(omega/sqrt(sigma2))*E+sqrt(tau2-omega²/sigma2)*H. Algebraically this
reconstructs the noise covariance; invalid covariance raises an error.
X is independent of E,H; cases are independent. No finite covariance matching,
centering/whitening, outlier removal, intercept, ridge, clipping or jitter.
Y=X beta+epsilon,T=X gamma+xi,V=(1-lambda)Y+lambda T.

Each replicate creates one X,Y,T,V and Z=X A^T. FO=X,Y; FT=X,T;
RO=Z,Y; RM=Z,V. Fit FP64 np.linalg.lstsq(rcond=None) once per method.
Solver signature is (design,target), with no model parameters or theory.
Prediction coefficients are never corrected. Planned20000 datasets,80000
fit objects/solver calls/rows; four fits are paired, not80000 datasets.

## Risk and direct expectation mapping

Main fitted risk is e^T Sigma e: e=theta_hat-beta (FO/FT),
e=A^T w_hat-beta (RO/RM). It excludes fresh observation noise, is not training
MSE, and needs no full-run test dataset. Anchor coordinate check is sum(e²),
or .08+sum((w_hat-beta[:3])²) for RO/RM.

General projection uses solve(C,A Sigma beta/gamma), C=A Sigma A^T;
u_beta=beta-A^T w_beta,u_gamma=gamma-A^T w_gamma.
B=.2378,B_A=.08,D_A=.0753,G_A=.4625,S_A=.19. These population solves are
not the data OLS solver and do not pass oracle coefficients to it.
Lemma3.1/Proposition3.2/Proposition4.1/Theorem4.3 yield:

    FO=sigma2*d/(n-d-1) = 13/42
    FT=B+tau2*d/(n-d-1) = 6067/15000
    RO=B_A+r*(B_A+sigma2)/(n-r-1) = 13/50
    RM=B_A+lambda²*D_A+r/(n-r-1)*bracket = 9516257/46000000
    bracket=(1-lambda)²*(B_A+sigma2)+lambda²*(G_A+tau2)
            +2lambda(1-lambda)*(S_A+omega) = .85580625.

Independent scalar/Fraction calculation and matrix projection must agree.
These are pre-full analytic predictions, not MC measurements. RM expectation
decomposes into .08+.01524825+0+.111626902173913...=.206875152173913....
With h=w_hat-[(1-lambda)w_beta+lambda w_gamma], each fit instead includes
the signed term 2lambda(w_gamma-w_beta)^T C h plus h^T C h. FT similarly
has2delta^T Sigma(theta_hat-gamma). Preserve them in raw/summary/plots;
only their population expectations are zero. The fixed lambda=.45 value is
not the paper's optimized-lambda minimum. No n/lambda sweep is implemented.

## RNG, pilot, freeze and accounting

NumPy Generator(PCG64(SeedSequence([2026102102,stream_id,replicate_id]))).
Streams X0,E1,H2,test-MC3; replicate is zero-based, method absent. Draw
X shape(n,d),E/H shape(n) with separate generators. Stable keys independently
seed generators so batch/order/restart does not affect data. Separate pilot
uses streams100/101/102/103 and50 replicates; unit/training-check fixtures
use200/201/202/203. Independent test inputs use stream3 and2 model-set IDs.
No bootstrap or hidden teacher RNG. P1 seed2026102101 and original PyTorch
seed20261016 are distinct. Equal integers would not equalize RNG backends.

P2 smoke:12 new contract/pipeline tests; one original17-test P1 regression
invocation; eight risks for two fixed model sets checked with100000 independent
test inputs/set at6 sample MC-SE;50-replicate pilot,200 fits; pilot verify and
plot. These are separate costs, not full samples. Original P1 unit calls are
not instrumented; P2 lstsq and QR validation calls are instrumented by phase.
Repeated invocation does not increase the unique test count. No P1 full rerun.

After required checks, commit the scientific source, then freeze config,
this protocol/source mapping, source bytes/SHA256/copies, environment,
metrics/pairs/plots/diagnostics, actual UTC start and git source commit. Bundle
SHA256 hashes a canonical sorted path/bytes/hash manifest; config has a separate
SHA256. Later reports are outside the frozen scientific source. Science/config
changes require preserved original run/new version; diagnostic-only corrections
can reanalyze immutable raw with original verdict/reason retained. No need to
repeat the same full samples merely for a display correction.

Batch200, serial streaming, wall cap7200s checked each batch. Benchmark the
pilot then hold this batch for full. Child-only BLAS threads1 from scripts/teg;
existing attention Python, pinned NumPy/Matplotlib; no installs/upgrades.
Rank/nonfinite/exception rows remain explicit. PARTIAL preserves raw/actual
counts and cause; never lower repetitions silently or replace anomalous seeds.

## Raw schema, statistics and verification

UTF-8 CSV, Python float round-trip decimals, CRLF records; .gitattributes
preserves exact evidence bytes. datasets.csv:dataset_key,replicate,seed_X/E/H,
X/Z/noise/Y/T/V/combined-target SHA256,status,error. Hash is concatenated
little-endian FP64 C-order bytes with shapes fixed by config; combined noise
order epsilon,xi; combined target orderY,T,V. Fits.csv unique key=(replicate,method),
dataset/hash references,coefficient_count,coef0..4 (last two blank for3D heads),
rank,status,error,truth_risk,representation_loss,teacher_bias,cross_term,
estimation_quadratic,decomposition_total. Failed values are textual nan and
remain in denominators. No full X/target arrays need be saved.

Four method summaries: R_planned/R_rows/N_valid/N_failed/N_missing,mean,
sample SD(ddof1),MC-SE,pointwise mean±1.96SE,theory,difference,z. Six unordered
pairs are fixed in config order:FO-FT,FO-RO,FO-RM,FT-RO,FT-RM,RO-RM; sign is
left-minus-right. SE uses replicate differences and shared dataset keys.
Components have equivalent summaries. Do not add these dependent metrics as
independent evidence. Flag |difference|>4SE for investigation; all95% intervals
containing theory is not a pass criterion. No post-full tolerance change.

Atol1e-10,rtol1e-9 for deterministic FP64 tests. Structural controls are
classified from targets/design/noise, never observed z. Main four risks and
six contrasts are stochastic; constants/known-zero component identities use
tolerance. Zero SE is never divided. Execution,implementation,statistics and
publication statuses remain separate; publication is LOCAL_ONLY.

Verify all raw hashes/keys/coverage/data-sharing/coefficients/risk identities,
then preselected replicates0,1,2,7,19,49,101,999,4095,8191,12345,19999:
regenerate12 datasets, replay48 method fits,48 independent QR solves,12 extra
representation-teacher fits for OLS mixture linearity. Verification thus adds
60 lstsq calls, not80000 new fits. Filter unavailable keys for the50-run pilot.
Require explicit new verification output path; never call P1 receipt-writing
verify on original runs. Rebuild summary/figures from existing P2 raw in a fresh
external directory; compare all numbers and file hashes, not another full sweep.

Plots PNG+SVG: (1) four methods theory expectation vs MC means/pointwise95%;
(2) RM expected and actual four components, signed cross term, actual total.
Inspect generated images and report only the performed internal AI-assisted
visual/numerical checks. No human-independent review claim. No new GPU/model,
paid API, remote publication, non-Gaussian/probit/LLM/CFPB or train/test shift.

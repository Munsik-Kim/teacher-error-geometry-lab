# P2 보고서 — 원문 Gaussian 회귀 고정 설정의 부분 수치 재현

2026-10-21 KST. P2 로컬 구현·20000반복 full·검산·그림·한영 보고서·인계를 완료했다.
원문 Table1의 한 설정에 대한 부분 수치 재현이며 새 정리·알고리즘 또는 논문 전체
재현이 아니다. 최종 run은 `p2_paper_anchor_20261021T065112Z`,P2 full 실행은1회다.

| Field | Value |
| --- | --- |
| execution_status | COMPLETE |
| implementation_verification | PASS |
| statistical_comparison | NO_4SE_FLAGS |
| publication_readiness | LOCAL_ONLY |
| P1_preservation | PASS |

## 원문 대응과 P1 원형 보존

[원문 v1 §3.1·§3.2·§4.1·§4.2·§7.1/Table1](https://arxiv.org/html/2610.26797v1)을
직접 읽었다. d5/r3/SigmaI5/A=[I3,0],beta/delta,잡음,R20000,lambda.45가 요청값과
일치한다. n27은 원문의 표본 수 목록 중 한 점이다. 위치·가정·구현 변수·검증은
[P2_SOURCE_MAP.ko.md](P2_SOURCE_MAP.ko.md)에,full 전 고정 규칙은
[P2_PROTOCOL.md](P2_PROTOCOL.md)에 기록했다. 저자 코드는 열람·복사하지 않았다.
원문 PyTorch generator/seed20261016과 이번 NumPy PCG64/root2026102102는 다르다.
같은 분포·파라미터·기대 위험을 재현하며 원문 표본·MC 평균의 bitwise 복제가 아니다.

P1 보호 목록340파일·92111045bytes의 시작/종료 path·bytes·SHA256이 일치했다.
첫/최종 full,P0,raw·snapshot·receipt,기존 재생성,보고서·theory·source_access·
RUN_HISTORY,config/tests/과학 모듈과 기존 인계를 원형 보존했다. 공유 CLI만 확장했다.
P1 원 run에 verify receipt를 새로 쓰거나 P1 full을 돌리지 않았다. 기존 고유 검사17개는
이번에1회 재실행해 통과했으며 새 P2 검사12개와 분리한다.
P1은168000fit·62000고유dataset이고 역사적 full2회의336000호출은 같은2000표본의
재실행이다. 독립4000반복으로 합치지 않았다. 첫 paired 각도 비교의 결정성 분류 누락과
결과 관측 뒤 수정·재실행한 이력을 지우지 않았으며 처음부터 미관측 사전등록이었다고
표현하지 않는다. [단계 이력](P2_RUN_HISTORY.md)과 P2 run의 보존 receipt를 남겼다.
P1의 B_A=0 특수형에서 P2는 B_A=.08과 S_A+omega=.41까지 확인 범위를 넓혔다.

## 동결 소스·환경·구현

작업경로: `/home/mskim/Codex_main/teacher-error-geometry-lab`. 실행 source commit: `9b502ee4739e7acb43f94a89bdf57cfbc303a38b`.
Source bundle SHA256: `fc3f8e3e43beb117efd16c391d89a0d7b3d103611613d78639c869a01ddd20c7`.
Frozen config SHA256: `510781991629e037bd2dc1d66aa4533c7d903b3315b04050a53ee9cca2c1b4ef`.
실제 시작 UTC: `2026-10-21T06:51:12.343489+00:00` (2026-10-21 15:51:12 KST).
[Freeze](../runs/p2_paper_anchor_20261021T065112Z/provenance/freeze.json)에 소스별 path/bytes/hash·복사본·환경을
남겼다. Config hash는 provenance/config.json bytes 기준이며 원 config 파일의
bytes/hash도 source manifest에 있다. 보고서·시각 점검·전달 metadata는 실행 후
작성했고 과학 소스/config는 full 동결 뒤 바꾸지 않았다. 시작 시 미추적 경로는
새 runtime 출력뿐이었다. P2 bundle hash는 smoke 때와 동일하다.

기존 `/home/mskim/miniforge3/envs/attention/bin/python`,Python3.11.15,
NumPy1.26.4,Matplotlib3.10.9,OpenBLAS64 build0.3.23.dev,
WSL2 Linux5.15.167.4,AMD Ryzen7 9800X3D를 사용했다. Wrapper의 TEG_PYTHON
선택을 유지했고 BLAS thread1·Agg·cache는 자식 프로세스에만 적용했다.
설치·업그레이드는0이다. [환경 원본](../runs/p2_paper_anchor_20261021T065112Z/provenance/environment.json).

독립 Gaussian X와 분산1.3/.7·공분산.22의 결합 Gaussian epsilon/xi를 생성했다.
Noise factor가 covariance와 determinant.8616을 재구성한다. Omega는 상관계수가
아니다. X/E/H seed는 분리하며 method ID를 넣지 않았다. 공통
Y=X beta+epsilon,T=X gamma+xi,V=.55Y+.45T,Z=X A^T로
FO(X,Y),FT(X,T),RO(Z,Y),RM(Z,V)를 학습했다. 각 방식은 배정된 design/target만
받는 절편·규제 없는 FP64 lstsq1회다. Population projection solve는 평가자·이론용이며
solver에 oracle 계수를 전달하지 않는다. Normal-equation 역행렬,계수 정답 보정,
whitening,jitter,clipping,필터,full 반복마다 큰 test set을 사용하지 않았다.

주 지표는 관측 Y가 아닌 참 신호 X beta 대비 risk다.80000행 모두 실제 fitted 계수의
5D quadratic form을 사용했다. 독립 좌표·QR·OLS target 선형성·scalar/Fraction
기대값·RM/FT signed sample 분해가 통과했다. 기대값은 각각
FO=13/42,FT=6067/15000,RO=13/50,RM=9516257/46000000이다.

## 네 방식과 여섯 paired 비교

고유 학습dataset20000회,방식마다20000fit,합80000행·fit object·실제 lstsq호출이다.
모두 유효하며 rank 결함·비유한·예외·누락은0이다.80000개 독립 dataset이 아니다.

| 방식 | 계획 / 행 / 유효 / 실패 / 누락 | 이론값 | MC 평균 | SD | MC-SE | Pointwise 95% 구간 | 평균-이론 | z |
| --- | --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| FO | 20000 / 20000 / 20000 / 0 / 0 | 0.3095238095 | 0.3101549484 | 0.2314733872 | 0.001636764018 | [0.3069468909, 0.3133630058] | 0.0006311388282 | 0.3856016026 |
| FT | 20000 / 20000 / 20000 / 0 / 0 | 0.4044666667 | 0.4038669197 | 0.2147372939 | 0.001518421967 | [0.4008908126, 0.4068430268] | -0.0005997469654 | -0.3949804327 |
| RO | 20000 / 20000 / 20000 / 0 / 0 | 0.26 | 0.2598640016 | 0.163010949 | 0.001152661475 | [0.2576047852, 0.2621232181] | -0.0001359983577 | -0.1179863825 |
| RM | 20000 / 20000 / 20000 / 0 / 0 | 0.2068751522 | 0.2076789594 | 0.1118263778 | 0.0007907319008 | [0.2061291249, 0.209228794] | 0.0008038072709 | 1.016535782 |

네 방식 모두 WITHIN_4SE이고 최대|z|=1.016536이다. 결과를 보고 tolerance·seed를
바꾸지 않았다. SD는 표본 ddof1,MC-SE=SD/sqrt(N_valid),pointwise 정규근사95%
구간은 mean±1.96SE다. 동시 구간이 아니며 모든95% 구간 포함을 PASS 기준으로 쓰지
않았다. 관측 순서·유의성으로 실행 완료나 구현 검증 여부를 결정하지 않는다.

| 왼쪽-오른쪽 | 이론 차이 | 평균 차이 | Paired MC-SE | z | 유효 pair |
| --- | ---: | ---: | ---: | ---: | ---: |
| FO-FT | -0.09494285714 | -0.09371197135 | 0.002176195708 | 0.5656135563 | 20000 |
| FO-RO | 0.04952380952 | 0.05029094671 | 0.001265617205 | 0.6061368184 | 20000 |
| FO-RM | 0.1026486573 | 0.1024759889 | 0.001523220747 | -0.1133574651 | 20000 |
| FT-RO | 0.1444666667 | 0.1440029181 | 0.001863620178 | -0.2488428776 | 20000 |
| FT-RM | 0.1975915145 | 0.1961879603 | 0.001530741648 | -0.9169112487 | 20000 |
| RO-RM | 0.05312484783 | 0.0521850422 | 0.000834703569 | -1.125915431 | 20000 |

여섯 비교 모두 WITHIN_4SE,최대|z|=1.125915다. 각 pair는 공통20000반복을 쓰고
dataset key 불일치는0이다. 부호는 왼쪽-오른쪽이며 SE는 실제 반복별 차이에서
계산한다. 독립 집단 SE가 아니다. Pair·분해 성분은 서로 의존하는 추가 지표다.

## RM·FT의 실제 분해

일반 투영 경로는 B=.2378,B_A=.08,D_A=.0753,G_A=.4625,S_A=.19를 준다.
RM 대괄호=.85580625,잔차 결합=.41이다. Lambda.45의 기대 위험은
.08+.01524825+0+.111626902173913...=.206875152173913...이다.
이는 학습 표본 재생성 기대값이며 개별 fit 성분을 대신하지 않는다.

| RM 성분 | 기대값 | 실제 평균 | MC-SE | z 또는 결정적 규칙 |
| --- | ---: | ---: | ---: | --- |
| representation_loss | 0.08 | 0.08 | 1.962664641e-19 | tolerance |
| teacher_bias | 0.01524825 | 0.01524825 | 3.679996201e-20 | tolerance |
| cross_term | 0 | 0.000411069841 | 0.0003374848741 | 1.218039304 |
| estimation_quadratic | 0.1116269022 | 0.1120196396 | 0.0007112582635 | 0.552172748 |
| decomposition_total | 0.2068751522 | 0.2076789594 | 0.0007907319008 | 1.016535782 |

RM 교차항의 실제 평균은 **+0.00041106984100782904**이며0으로 강제하지 않았다.
SE=.00033748487411251293,z1.218039다. 실제 추정 quadratic 평균은
.1120196396037602다. 이 값들과 .08,.01524825를 합하면 실제 truth 평균
.20767895944476805와 FP64 범위에서 같다. 개별 RM 행도 각자의 signed cross를
포함한 항등식을 통과했다. FT 교차항 평균은 **-.0005603832093237588**,
SE=.0012548428537834792,z=-.446576이다. 성분의 미해결 조사 대상도0이다.
결정적인 상수·정확히0인 항은 사전 atol1e-10,rtol1e-9로 검사하고 작은 SE로 나누지 않는다.

이 고정 설정에서는 RM 실측 위험이 가장 작았다. 이를 일반 증류/표현 압축 우위,
n축 threshold 또는 최적 lambda 검증으로 확대하지 않는다. 원문의 최적화된 compressed
최소값 약.2066과 이번 고정 lambda.45의 기대값 .206875152173913...은 다르다.

## 비용·독립 검산·외부 경로 재생성

| 단계 | Wall 초 | CPU 초 | Peak RSS MiB |
| --- | ---: | ---: | ---: |
| Full runner | 5.903 | 5.913 | 58.35 |
| full_cli_cost | 6.07 | 6.08 | 59.27 |
| summary_cli_cost | 1.21 | 1.05 | 132.75 |
| figures_cli_cost | 0.74 | 0.69 | 94.55 |
| verify_cli_cost | 10.66 | 10.51 | 115.25 |
| rebuild_summary_cli_cost | 1.04 | 1.03 | 133.20 |
| rebuild_figures_cli_cost | 0.78 | 0.69 | 93.86 |

Runner 계측은 동결 준비부터 실험 최종 receipt까지다. Full CLI는 시작·raw hash까지
포함한다. CPU/RSS는 해당 프로세스 실측이며 하드웨어 정규화 성능 벤치마크가 아니다.
배치200,순차 실행,상한7200초이며 자원 중단은 없었다. Raw CSV는
49275674bytes(46.99MiB)로 로컬 보존하고 첨부·ZIP으로 묶지 않았다.

| 단계 | 실제 lstsq 호출 | 별도 QR 검산 |
| --- | ---: | ---: |
| P2 unit tests (12 unique) | 86 | 16 |
| Independent test-MC (2 model sets,8 risks) | 8 | 0 |
| Pilot (50 datasets,200 rows) | 200 | 0 |
| Pilot verification (6 datasets) | 30 | 24 |
| Full (20000 datasets,80000 rows) | 80000 | 0 |
| Full verification (12 datasets) | 60 | 48 |
| Summary/figures/rebuild | 0 | 0 |

P2 unit dataset 생성 총수는 따로 계측하지 않았다. Pilot50/full20000 생성 수는 실제
계측값이며 full verify는12,pilot verify는6dataset을 재생성했다. 독립 MC는 학습2dataset과
fresh test-input2세트(각100000행)를 사용하고 각 세트를 네 모델이 공유한다. 위험8개를
독립8dataset으로 세지 않는다. P2 unit wall/CPU는
0.129/0.069초,
P1 회귀는0.349/0.335초다.
원래 P1 unit solver 총수는 계측되지 않았다. Pilot runner는
0.153/0.088초,
전체 smoke는1.227초·peak RSS104.07MiB다.
이 비용·표본을 full MC 평균에 합치지 않았다.

Raw 전체 hash·고유 key·분모·pairing·rank·계수·quadratic/좌표 risk·signed 분해가
통과했다. 사전 선택12dataset key를 seed에서 재생성해 X/잡음/target hash와48개
방식의 계수·risk를 대조했다. Verify의60lstsq에는 mixture 선형성용 representation-
teacher12fit이 포함된다. 별도 QR은48회다.
[검증 receipt](../runs/p2_paper_anchor_20261021T065112Z/provenance/verification.json).

새 외부 경로 `/home/mskim/Codex_main/teacher-error-geometry-p2-rebuild-20261021T065112Z`에서 재생성했다.
Summary5·PNG/SVG4·figure manifest1=10파일의 bytes/hash가 일치했고 full을 다시
돌리지 않았다. [재생성 receipt](../runs/p2_paper_anchor_20261021T065112Z/provenance/reproduction.json).
PNG2종과 기존 system librsvg/Cairo로 렌더링한 SVG2종의 축·레이블·실제값·signed
cross를 시각 점검했다. 내부 AI 보조 검산·시각 점검이며 사람 독립 심사나 외부 실행이
아니다. 환경 간 byte 동일성을 보장하지 않는다.

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
./scripts/teg p2 verify --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-verify-NEW_ID.json
./scripts/teg p2 summarize --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-rebuild-NEW_ID/summary
./scripts/teg p2 figures --summary /tmp/teg-p2-rebuild-NEW_ID/summary --output /tmp/teg-p2-rebuild-NEW_ID/figures
# Optional future smoke; recorded P1 regression can be reused rather than invoked again.
./scripts/teg p2 smoke --p1-baseline p2_preflight/20261021T063310Z/p1_before.json --reuse-p1-regression-receipt p2_preflight/20261021T063310Z/smoke_01/p1_regression.json --output /tmp/teg-p2-smoke-NEW_ID
# Optional future full, not needed to rebuild existing raw outputs.
./scripts/teg p2 run --config configs/p2_paper_anchor.json --p1-baseline p2_preflight/20261021T063310Z/p1_before.json --output /tmp/teg-p2-full-NEW_ID
```

출력 경로는 새 경로를 사용한다. P2 verify는 명시적 output이 필요하며 기존 receipt를
덮어쓰지 않는다. Wrapper는 PYTHONPATH=src와 기존 Python을 사용하며 TEG_PYTHON
선택도 유지했다. [실제 재현 안내](reproduce.md). 원형 보존 P1 run에 root verify를
실행하지 않는다. 별도 필요 시에만 옛 snapshot·외부 receipt를 사용할 수 있고 이번에는
그 추가 P1 verify도 실행하지 않았다.

## 로컬 전달과 P3

현재 상태는 LOCAL_ONLY다. P3에는 문서·claim 검토,깨끗한 환경 재현(현재 NOT_RUN),
의존성·metadata 검토,공개 준비 항목을 넘긴다. 원격 생성/push/PR/Pages는 수행하지
않았으며 별도 사용자 지시 범위다. n/lambda sweep,비Gaussian,학습/평가 covariance
shift,probit,실제 LLM,GPU로 확대하지 않았다. GPU·모델요청·모델다운로드·유료API·
설치업그레이드·원격게시 모두0이다. 무관한 프로젝트·서비스를 바꾸거나 종료하지 않았다.
MIT는 독립 작성물만이며 원문 권리·AI 보조 구현은 NOTICE에 명시돼 있다.
한영 공통 수치는 [P2_report_facts.json](P2_report_facts.json)에 있다.
작은 UTF-8 인계는 worktree 밖
`/home/mskim/Codex_main/handoffs/teacher_error_geometry_P2_20261021.txt`로 전달한다.

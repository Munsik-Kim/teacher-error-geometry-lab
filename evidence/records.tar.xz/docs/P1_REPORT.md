# P1 report — Teacher Error Geometry Lab

2026-10-21 KST. Canonical run: `p1_full_20261021_02`. Local CPU P0/P1 is complete.
This independently implemented two-dimensional Gaussian special case agrees
with its analytic risks under the frozen diagnostic rules. It is a reproduction
portfolio artifact, not a new algorithm or a reproduction of the entire paper.

| Field | Value |
| --- | --- |
| execution_status | COMPLETE |
| implementation_verification | PASS |
| statistical_comparison | NO_4SE_FLAGS |
| publication_readiness | LOCAL_CANDIDATE_READY |
| paper_correspondence | READ_AND_MAPPED_SPECIAL_CASE_ONLY |

## Scope, provenance and method

Workspace: `/home/mskim/Codex_main/teacher-error-geometry-lab`. Execution commit: `df1173e91e77a43a53e9a82beea079c65bd0dab6`.
Source bundle SHA256: `286b7639b3abfb69503926dad32f35dc27ddd11356a8a15fe2b72377e37716a2`.
Frozen config SHA256: `f909d298b234af6a3a1a4175066004bd203d91d0ac9912cb34271e058551a11b`.
Actual start UTC: `2026-10-21T06:03:10.472950+00:00` (2026-10-21 15:03:10 KST).
The new run directory was the only untracked path at freeze; tracked execution
source was committed. Reports/rebuild metadata were written afterward without
changing frozen scientific source. File bytes/hashes and copies are in
[freeze.json](../runs/p1_full_20261021_02/provenance/freeze.json).

Directly read [v1 §4.2 Theorem 4.3 and Corollary 4.5](https://arxiv.org/html/2610.26797v1#S4.SS2).
The mapping is A=[1,0], beta=(1,0), gamma=beta+delta, r=1,lambda=1,
zero extra noise, B_A=0,D_A=a²,G_A=b². See [direct derivation](theory.md)
and [source-access record](source_access.md). No author code was accessed.

Independent X1,U generate X2=rho*X1+sqrt(1-rho²)*U. The no-intercept,
unregularized FP64 learner receives only Z=X1 and T. Each target calls
np.linalg.lstsq once. Evaluate fitted population risks with the quadratic form;
compute training-sample expectations separately. There is no training-MSE proxy,
no large test set per full fit, no data whitening or sample covariance correction.

## Denominators and actual resources

| Block | Cells | Planned / actual fitted rows | New datasets | Reused A references |
| --- | ---: | ---: | ---: | ---: |
| A | 50 | 100000 / 100000 | 50000 | 0 |
| B | 10 | 20000 / 20000 | 0 | 20000 |
| C | 24 | 48000 / 48000 | 12000 | 0 |
| Total | 84 | 168000 / 168000 | 62000 | 20000 |

All cells have R_planned=R_rows=N_valid=2000; N_failed=N_missing=0.
Actual fit objects=168000, solver calls=168000, unique dataset-generation
calls=62000. B performs additional fits on A's actual data. At rho0, B and hidden
are identical targets; their results are one reused observation, not confirmation
from another sample. The two risks of a fit are not independent observations.

| Phase | Wall s | CPU s | Peak RSS MiB |
| --- | ---: | ---: | ---: |
| P1 experiment (runner) | 9.240 | 9.238 | 55.20 |
| summary | 1.64 | 1.62 | 370.88 |
| figures | 2.56 | 2.49 | 124.70 |
| verify | 14.49 | 14.45 | 158.34 |
| rebuild_summary | 1.62 | 1.60 | 371.02 |
| rebuild_figures | 2.46 | 2.49 | 127.03 |

Runner time covers its frozen setup and serial experiment through the final
execution snapshot; CLI startup/final raw-manifest hashing are outside that
internal timer. Other phases use /usr/bin/time. Batch200, child BLAS threads1,
wall cap7200s; no resource stop occurred. Raw CSV is 43482396 bytes
(41.47 MiB). Summary loading, rather than fitting, had the
largest measured memory footprint. Final P0:17 tests PASS, six risk checks on three
fixed fits with fresh test inputs PASS (100000 inputs/model), plus a separate covariance
smoke diagnostic. P0 pilot:20 repeats/cell,1680 fits,620 datasets,
0.107s; whole P0 peak RSS 70.73MiB.

Environment: Python3.11.15, NumPy1.26.4, Matplotlib3.10.9; AMD Ryzen7 9800X3D,
WSL2 Linux5.15.167.4. NumPy reports OpenBLAS64 0.3.23.dev build configuration.
[Environment capture](../runs/p1_full_20261021_02/provenance/environment.json) includes the
exact Python, OS, BLAS and child thread variables. Existing CPU environment was
used read-only; no packages were installed/upgraded.

## Observed risks and interpretation

Every table entry is an actual R=2000 MC estimate, including deterministic FP64
controls. The predictions in the next paragraph are separate analytic values.

| Cell (rho,n) | Metric | MC mean | MC-SE | Pointwise 95% CI | Theory | z or rule |
| --- | --- | ---: | ---: | --- | ---: | --- |
| A_r2_n1_axis_visible (0.0,30) | truth_risk | 0.25 | 8.655496233e-18 | [0.25, 0.25] | 0.25 | tolerance |
| A_r2_n1_axis_visible (0.0,30) | teacher_risk | 1.497603125e-31 | 4.840661328e-33 | [1.402726163e-31, 1.592480087e-31] | 0 | tolerance |
| A_r2_n1_axis_hidden (0.0,30) | truth_risk | 0.008460831453 | 0.0002714734544 | [0.007928743482, 0.008992919423] | 0.008928571429 | -1.722967636 |
| A_r2_n1_axis_hidden (0.0,30) | teacher_risk | 0.2584608315 | 0.0002714734544 | [0.2579287435, 0.2589929194] | 0.2589285714 | -1.722967636 |
| A_r2_n3_axis_hidden (0.0,300) | truth_risk | 0.0008330708234 | 2.615235311e-05 | [0.0007818122113, 0.0008843294355] | 0.0008389261745 | -0.2238938512 |
| A_r2_n3_axis_hidden (0.0,300) | teacher_risk | 0.2508330708 | 2.615235311e-05 | [0.2507818122, 0.2508843294] | 0.2508389262 | -0.2238938512 |
| A_r4_n4_axis_hidden (0.9,1000) | truth_risk | 0.2025503873 | 0.000141711919 | [0.2022726319, 0.2028281427] | 0.2025475952 | 0.01970273619 |
| A_r4_n4_axis_hidden (0.9,1000) | teacher_risk | 0.04754944931 | 1.547725884e-06 | [0.04754641576, 0.04755248285] | 0.04754759519 | 1.197961281 |
| B_r4_n1_projection_zero (0.9,30) | truth_risk | 0.008805482068 | 0.0002880140519 | [0.008240974526, 0.009369989609] | 0.008928571429 | -0.4273727626 |
| B_r4_n1_projection_zero (0.9,30) | teacher_risk | 0.2588054821 | 0.0002880140519 | [0.2582409745, 0.2593699896] | 0.2589285714 | -0.4273727626 |
| C_r1_n1_t2 (0.0,300) | truth_risk | 0.0007675668765 | 2.357325768e-05 | [0.0007213632915, 0.0008137704616] | 0.0008389261745 | -3.027129256 |
| C_r1_n1_t2 (0.0,300) | teacher_risk | 0.2507675669 | 2.357325768e-05 | [0.2507213633, 0.2508137705] | 0.2508389262 | -3.027129256 |

At c=.5,rho0,n30 the **analytic prediction** is visible truth=.25, teacher0;
hidden expected truth=.25/28=.008928571428571428 and expected teacher
=.25892857142857145. Measured hidden truth is .00846083145254395, not the
prediction relabeled as data. Visible teacher MSE is about1.5e-31 from solver
roundoff and passes the deterministic zero tolerance. Agreement with that
teacher still coexists with truth risk .25. A separately gold-trained control
has mathematical truth risk0 and passes FP64 tolerance in P0; gold is never
provided to a teacher-training fit.

For B, a=0 and b=.5 for every rho: expected truth is .008928571428571428 at
n30 and .0008389261744966443 at n300. Finite-sample means fluctuate around
these values. A hidden error has asymptotic floor c²rho², e.g. .2025 at rho.9;
the n1000 observed truth .20255038730293556 tracks that floor plus variance.
C has exactly3rho x4theta x2n=24 cells. All have population teacher error .25;
Euclidean coefficient norms differ. Its eta alignment follows
E[R_truth]/c²=eta+(1-eta)/(n-2).

There are168 marginal metric summaries:62 deterministic PASS and106 WITHIN_4SE.
Paired differences give162 summaries:6 deterministic PASS and156 WITHIN_4SE.
Maximum |z| is 3.027129 marginal and 3.027129 paired;
no unresolved >4SE flags. These summaries are dependent and are not extra
independent observations. Sample SD uses ddof1, MC-SE=SD/sqrt(N_valid),
pointwise normal95%=mean±1.96SE; these are not simultaneous intervals. Some
pointwise intervals miss theory: C rho0,n300,theta pi/2 has truth z=-3.027129.
That is below the predeclared investigation threshold and is not evidence that
all exact formulas have been proven. Deterministic comparisons use
atol1e-10,rtol1e-9 per replicate and no z division.

## Preserved issue and corrected execution version

The first P0 attempt had a harness attribute-name error; the failed record is
preserved. The first full run completed in 9.168s
and its raw data were correct. Its summary omitted the deterministic shared-data
identity for C rho0,theta pi/4 versus3pi/4 teacher-risk differences. It displayed
two FP64 artifacts as z17.973973/42.247806, with absolute mean-theory
differences1.54e-17/1.65e-17. The old flags and source remain intact.

For those pairs the exact risks are b²(1+Q²) with the same b² and Q. Added that
structural classification and a regression check, preserving the original
tolerance, learner, generator, risks, seed and full grid. Ran a new P0 and the
new full run ID. All32 raw-file hashes and marginal cells.csv bytes match the
first run exactly. Only the paired diagnostic treatment changed; no anomalous
seed/cell was replaced. See [run history](RUN_HISTORY.md).

Cost accounting:two full invocations=336000 solver calls and124000 dataset
regeneration events, but only62000 distinct dataset keys; both use the same
2000 replicates. Their summed experiment time is
18.408s. They are not4000 independent
replicates. P0 unit-test aggregate solver calls were not instrumented and are not
included in these full-run counts. The canonical verification adds32 replay
solver calls on12 fixed datasets; no further full sweep was used for rebuild.

## Reproduction and artifacts

Full raw integrity/keys/seed mapping/pairing/risk identities passed, and12 fixed
seeded datasets regenerated matching data hashes, scalar/lstsq coefficients and
risks. Rebuilt raw→summary→figures in a new directory:
`reproductions/p1_full_20261021_02_rebuild_01`. All15 compared files
(4 summary files,10 PNG/SVG files,1 figure manifest) are byte-identical in this
environment. [Verification](../runs/p1_full_20261021_02/provenance/verification.json),
[rebuild evidence](../runs/p1_full_20261021_02/provenance/reproduction.json),
[final status](../runs/p1_full_20261021_02/provenance/final_status.json),
[shared bilingual facts](report_facts.json).

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
# Existing CPU environment; wrapper sets PYTHONPATH, Agg, local cache, BLAS threads=1.
./scripts/teg verify --run runs/p1_full_20261021_02
./scripts/teg smoke --output /tmp/teg-p0-YOUR_NEW_ID
./scripts/teg summarize --run runs/p1_full_20261021_02 --output /tmp/teg-rebuild-YOUR_NEW_ID/summary
./scripts/teg figures --summary /tmp/teg-rebuild-YOUR_NEW_ID/summary --output /tmp/teg-rebuild-YOUR_NEW_ID/figures
# Optional future full rerun, not needed to inspect/rebuild the saved results.
./scripts/teg run --config configs/p1.json --output /tmp/teg-full-YOUR_NEW_ID
```

All create-output commands require an unused path. `TEG_PYTHON` may select
another compatible Python; wrapper defaults to the existing attention Python.
For direct module invocation, set PYTHONPATH=src and the child thread/Agg/cache
settings as documented in [reproduction guide](reproduce.md). The committed
CLI exists; no installation is needed for this wrapper. Optional project-local
.venv instructions are in that guide.

Five figures are saved as PNG+SVG in [figures](../runs/p1_full_20261021_02/figures).
Theory curves, MC means and pointwise intervals are separate. All five PNGs were
visually inspected for labels, axes and cell counts. This is internal
AI-assisted inspection, not an external review or a portable rendering proof.

## Remaining scope and delivery

P2 only on the roadmap:original Table1 d5/r3/n27,20000 repeats of full outcome,
full teacher,representation outcome,representation mixed. It is not implemented
or run. Non-Gaussian, train/test correlation shift, probit, actual LLM and CFPB
experiments are unrun. No novelty or serving/quantization benefit is claimed.
MIT covers only independently authored project materials; see LICENSE/NOTICE.
GPU jobs0,model requests0,model downloads0,paid API0,remote publication0.
Existing inference-lab,Direction–Scale,serving and ComfyUI environments were
not modified. Local candidate readiness does not mean whole-paper verification
or independent human approval. The small UTF-8 handoff is outside this worktree
at `/home/mskim/Codex_main/handoffs/teacher_error_geometry_P0_P1_20261021.txt`.

# Claim map and evidence boundary

| Claim | Implementation/evidence | Status before full |
| --- | --- | --- |
| Gaussian covariance by construction | model.generate, direct algebra in theory.md | Implemented; P0 gate pending |
| OLS learner sees only Z,T | solver.fit_student signature; scalar check | Implemented; P0 gate pending |
| E truth=a^2+b^2/(n-2) | independent direct derivation; theory.expectation | Paper correspondence READ; P1 comparison pending |
| Projection-zero removes population bias | Corollary4.5 correspondence; B vs paired A | P1 comparison pending |
| Teacher agreement differs from truth risk | quadratic evaluator; separate expectations and plot03 | P1 comparison pending |
| Normalized-angle relation | 24 C cells, eta curve and heatmap | P1 comparison pending |
| Gold-target noiseless control has risk0 | separate P0 control | P0 gate pending |
| Source/config/version frozen before full | provenance/freeze.json, source copies, local Git or bundle hash | Created at run start |

This document freezes the intended claims; post-run results and statuses belong
to P1_REPORT.md and P1_REPORT.ko.md. It does not get retroactively rewritten to
make the pre-run plan look verified.

Paper source: [Sudjianto and Burakov, v1 §4.2](https://arxiv.org/html/2610.26797v1#S4.SS2).
The teacher-agreement formula is a direct independent calculation here. P1 is a
2D special case, not the paper's Table1 experiment or a complete paper validation.
No novelty, performance improvement, LLM law, quantization, or serving claim is
made. Agreement is evidence of formula/code consistency under this exact model.

P2 roadmap ONLY: Table1 d5/r3/n27, full outcome/full teacher/representation
outcome/representation mixed,20000 repeats; original-setting comparison and
later correlation-change/non-Gaussian/LLM work. No P2 implementation or execution
is authorized in this run. Constant-rho independent cells in P1 are not a
train/test correlation-shift experiment.

## P2 scope extension dated 2026-10-21

The P1 roadmap above is preserved as its original pre-run claim boundary. The
user now authorizes the single Gaussian Table1 d5/r3/n27,lambda.45 anchor only.
No n/lambda sweep, non-Gaussian, train/test shift, probit or actual LLM work.

| P2 claim | Evidence planned before full | Status at this extension |
| --- | --- | --- |
| Four original-setting expectations | Matrix projections plus independent Fraction path | Implemented; smoke/full pending |
| Correlated target noise | factor covariance algebra and invalid-input tests | Implemented; smoke pending |
| Four actual fitted truth risks | paired data,assigned-input-only OLS,quadratic/coordinate checks | Implemented; full pending |
| RM representation loss and residual coupling | B_A=.08,S_A+omega=.41; signed sample cross terms | Implemented; full comparison pending |
| Preserved P1 history/results | start/end340-file path/bytes/hash inventory | Baseline recorded; final check pending |

See [P2 protocol](P2_PROTOCOL.md) and [original-source mapping](P2_SOURCE_MAP.ko.md).
These are expectation checks at one anchor, not generic distillation/compression
advantages or optimized-lambda validation. Final observed statuses belong to
P2 reports. All stages remain local; remote publication is outside scope.

# P2 report: one original-paper Gaussian regression anchor

2026-10-21 KST. P2 local implementation,20000-repeat full run,verification,
figures,bilingual reports and handoff are complete. This is a partial numerical
reproduction of one Table1 setting, not a new theorem/algorithm or full-paper
reproduction. Canonical run: `p2_paper_anchor_20261021T065112Z`. P2 full invocations:1.

| Field | Value |
| --- | --- |
| execution_status | COMPLETE |
| implementation_verification | PASS |
| statistical_comparison | NO_4SE_FLAGS |
| publication_readiness | LOCAL_ONLY |
| P1_preservation | PASS |

## Source correspondence and preserved P1

Read [v1 §3.1,§3.2,§4.1,§4.2 and §7.1/Table1](https://arxiv.org/html/2610.26797v1).
The requested d5/r3/SigmaI5/A=[I3,0],beta/delta,noise parameters,R20000 and
lambda.45 match the original. n27 is one original sample-size setting. Detailed
assumption/variable/test mapping is in [P2_SOURCE_MAP.ko.md](P2_SOURCE_MAP.ko.md),
and the [frozen P2 protocol](P2_PROTOCOL.md) was written before full results.
No author code was opened or copied. NumPy PCG64/root2026102102 differs from
original PyTorch/seed20261016; this reproduces distributions and expected risks,
not original samples,original MC means or bitwise RNG output.

P1 inventory protects340 files,92111045bytes:both full runs,P0 evidence,
raw/snapshots/receipts,rebuilds,old reports/theory/source_access/RUN_HISTORY,
config/tests/science modules and old handoff. Start/end path/bytes/SHA256 agree.
The shared CLI alone was extended; original P1 reports and artifacts were not
rewritten, and no P1 verify receipt or full run was generated. Its17 original
checks were invoked once and passed;12 P2 tests are separate unique checks.
P1 still means168000 fits on62000 unique datasets; its two historical full
invocations used the same2000 replicates (336000 calls), not4000 independent
replicates. The original paired-angle FP64 classification issue and observed
correction timeline remain preserved, not recast as unseen preregistration.
See [dated phase history](P2_RUN_HISTORY.md) and preservation receipts in this
P2 run. P1 remains an earlier B_A=0 special case; P2 checks B_A=.08 and
S_A+omega=.41 at the paper anchor.

## Frozen source, environment and implementation

Workspace: `/home/mskim/Codex_main/teacher-error-geometry-lab`. Source commit: `9b502ee4739e7acb43f94a89bdf57cfbc303a38b`.
Source bundle SHA256: `fc3f8e3e43beb117efd16c391d89a0d7b3d103611613d78639c869a01ddd20c7`.
Frozen config SHA256: `510781991629e037bd2dc1d66aa4533c7d903b3315b04050a53ee9cca2c1b4ef`.
Actual start: `2026-10-21T06:51:12.343489+00:00` (2026-10-21 15:51:12 KST).
[Freeze](../runs/p2_paper_anchor_20261021T065112Z/provenance/freeze.json) stores each source path/bytes/hash,
snapshots,environment and the committed source version. The config hash is of
provenance/config.json bytes; original config-file bytes also have a manifest
entry. Reports/visual inspection/delivery metadata were written after the run;
no scientific source/config changed after its freeze. Only newly created runtime
output paths were untracked at start. P2 source bundle matches the smoke source.

Existing Python `/home/mskim/miniforge3/envs/attention/bin/python`,Python3.11.15,
NumPy1.26.4,Matplotlib3.10.9,OpenBLAS64 build0.3.23.dev,WSL2 Linux5.15.167.4,
AMD Ryzen7 9800X3D. Wrapper TEG_PYTHON selection is retained; BLAS threads1,
Agg and cache settings apply to its children. No dependency installs/upgrades.
[Captured environment](../runs/p2_paper_anchor_20261021T065112Z/provenance/environment.json).

Each replicate generates independent Gaussian X and correlated epsilon,xi with
variances1.3,.7 and covariance.22. The noise factor reconstructs determinant
.8616; omega is not a correlation coefficient. X/E/H seeds are disjoint and
method-free. Y=X beta+epsilon,T=X gamma+xi,V=.55Y+.45T are shared among
FO(X,Y),FT(X,T),RO(Z,Y),RM(Z,V),Z=X A^T. Each fit is FP64 no-intercept,
unregularized single-target lstsq, receiving only its design/target. Population
projection solves are evaluator/theory calculations, never learner inputs.
No normal-equation inverse,oracle coefficient correction,whitening,jitter,
clipping,filtering or full-fit test dataset is used.

The primary risk is against the true signal X beta, not noisy observed Y.
All80000 rows use fitted coefficients in the5D quadratic form. Independent
coordinate checks,QR,OLS target linearity,scalar/Fraction expectations and
signed RM/FT sample decomposition identities passed. Expected values are
FO=13/42,FT=6067/15000,RO=13/50,RM=9516257/46000000.

## Main results and six paired contrasts

There are20000 unique training datasets and four20000-fit groups:80000 rows,
fit objects and actual lstsq calls. All valid; rank/nonfinite/exception failures0,
missing rows0. The four groups are paired and are not80000 independent datasets.

| Method | Planned / rows / valid / failed / missing | Theory | MC mean | SD | MC-SE | Pointwise 95% CI | Mean-theory | z |
| --- | --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| FO | 20000 / 20000 / 20000 / 0 / 0 | 0.3095238095 | 0.3101549484 | 0.2314733872 | 0.001636764018 | [0.3069468909, 0.3133630058] | 0.0006311388282 | 0.3856016026 |
| FT | 20000 / 20000 / 20000 / 0 / 0 | 0.4044666667 | 0.4038669197 | 0.2147372939 | 0.001518421967 | [0.4008908126, 0.4068430268] | -0.0005997469654 | -0.3949804327 |
| RO | 20000 / 20000 / 20000 / 0 / 0 | 0.26 | 0.2598640016 | 0.163010949 | 0.001152661475 | [0.2576047852, 0.2621232181] | -0.0001359983577 | -0.1179863825 |
| RM | 20000 / 20000 / 20000 / 0 / 0 | 0.2068751522 | 0.2076789594 | 0.1118263778 | 0.0007907319008 | [0.2061291249, 0.209228794] | 0.0008038072709 | 1.016535782 |

All four marginal comparisons are WITHIN_4SE; maximum|z|1.016536.
No tolerance or seed was changed after viewing results. SD is sample ddof1;
MC-SE=SD/sqrt(N_valid),pointwise normal95%=mean±1.96SE. These are not
simultaneous intervals; all95% inclusion is not a PASS criterion. Ordering or
significance does not define execution or implementation verification.

| Left minus right | Theory difference | Mean difference | Paired MC-SE | z | Valid pairs |
| --- | ---: | ---: | ---: | ---: | ---: |
| FO-FT | -0.09494285714 | -0.09371197135 | 0.002176195708 | 0.5656135563 | 20000 |
| FO-RO | 0.04952380952 | 0.05029094671 | 0.001265617205 | 0.6061368184 | 20000 |
| FO-RM | 0.1026486573 | 0.1024759889 | 0.001523220747 | -0.1133574651 | 20000 |
| FT-RO | 0.1444666667 | 0.1440029181 | 0.001863620178 | -0.2488428776 | 20000 |
| FT-RM | 0.1975915145 | 0.1961879603 | 0.001530741648 | -0.9169112487 | 20000 |
| RO-RM | 0.05312484783 | 0.0521850422 | 0.000834703569 | -1.125915431 | 20000 |

All six paired comparisons are WITHIN_4SE,maximum|z|1.125915; every pair
has20000 valid shared replicates,0 mismatched dataset keys. Left-minus-right
SE is computed from actual paired risk differences,not independent-group SE.
The extra paired rows and component metrics are dependent evidence.

## RM and FT actual decompositions

Projection gives B=.2378,B_A=.08,D_A=.0753,G_A=.4625,S_A=.19.
RM's expected bracket=.85580625 and residual coupling=.41. At lambda.45,
expected risk=.08+.01524825+0+.111626902173913...=.206875152173913....
These are expectations over regenerated training data, not per-fit components.

| RM component | Expectation | Actual mean | MC-SE | z or deterministic rule |
| --- | ---: | ---: | ---: | --- |
| representation_loss | 0.08 | 0.08 | 1.962664641e-19 | tolerance |
| teacher_bias | 0.01524825 | 0.01524825 | 3.679996201e-20 | tolerance |
| cross_term | 0 | 0.000411069841 | 0.0003374848741 | 1.218039304 |
| estimation_quadratic | 0.1116269022 | 0.1120196396 | 0.0007112582635 | 0.552172748 |
| decomposition_total | 0.2068751522 | 0.2076789594 | 0.0007907319008 | 1.016535782 |

The observed RM cross mean is **+0.00041106984100782904**,not forced to0;
its SE=.00033748487411251293,z1.218039. The actual estimation quadratic
mean is .1120196396037602. Together with .08 and .01524825 their sum matches
actual truth mean .20767895944476805 up to FP64 roundoff. Every RM row also
passed the identity including its own signed cross term. FT's signed cross
mean is **-.0005603832093237588**,SE=.0012548428537834792,z=-.446576.
No component investigation flags remain. Deterministic constants/known-zero
terms use predeclared atol1e-10,rtol1e-9 and are never divided by roundoff SE.

At this one setting RM's observed risk is lowest. That is not a general
claim of distillation or compression superiority,an n-axis threshold test or an
optimal-lambda result. The original optimized-lambda compressed minimum
(about.2066) is distinct from the fixed-.45 expectation .206875152173913....

## Costs, replay and external rebuild

| Phase | Wall s | CPU s | Peak RSS MiB |
| --- | ---: | ---: | ---: |
| Full runner | 5.903 | 5.913 | 58.35 |
| full_cli_cost | 6.07 | 6.08 | 59.27 |
| summary_cli_cost | 1.21 | 1.05 | 132.75 |
| figures_cli_cost | 0.74 | 0.69 | 94.55 |
| verify_cli_cost | 10.66 | 10.51 | 115.25 |
| rebuild_summary_cli_cost | 1.04 | 1.03 | 133.20 |
| rebuild_figures_cli_cost | 0.78 | 0.69 | 93.86 |

Runner timing covers freeze/setup and experiment through final receipt; full
CLI timing includes startup/final raw hashing. Phase CPU/RSS are process
measurements,not hardware-normalized performance benchmarks. Batch200,serial,
wall cap7200s; no resource stop. Raw CSV=49275674bytes
(46.99MiB),kept locally rather than attached or zipped.

| Phase | Actual lstsq calls | Extra QR solves |
| --- | ---: | ---: |
| P2 unit tests (12 unique) | 86 | 16 |
| Independent test-MC (2 model sets,8 risks) | 8 | 0 |
| Pilot (50 datasets,200 rows) | 200 | 0 |
| Pilot verification (6 datasets) | 30 | 24 |
| Full (20000 datasets,80000 rows) | 80000 | 0 |
| Full verification (12 datasets) | 60 | 48 |
| Summary/figures/rebuild | 0 | 0 |

P2 unit dataset-generation aggregate was not separately instrumented. Pilot50
and full20000 generation counts are actual; full verification regenerates12
and pilot verification6. Independent MC uses2 training datasets plus2 fresh
100000-row test-input sets shared across four fitted models each; eight risk
checks are not eight independent datasets. P2 unit checks took
0.129s wall/0.069s CPU;
P1 regression 0.349s/0.335s,
with original P1 solver total uninstrumented. Pilot runner
0.153s/0.088s;
whole smoke 1.227s,peak RSS104.07MiB.
These costs/samples are not folded into the full MC mean.

The verifier checked raw hashes,row uniqueness,all denominators,pairing,rank,
coefficients,quadratic/coordinate risks and signed decompositions. Replayed
preselected12 dataset keys from seed,matching X/noise/target hashes and all48
method coefficients/risks. Its60 lstsq calls include12 extra representation-
teacher fits for mixture linearity;48 independent QR solves are separate.
[Verification](../runs/p2_paper_anchor_20261021T065112Z/provenance/verification.json).

External rebuild: `/home/mskim/Codex_main/teacher-error-geometry-p2-rebuild-20261021T065112Z`. All10 files
(5 summary,4 PNG/SVG,1 figure manifest) match bytes/hashes. No second full
sweep was run. [Rebuild receipt](../runs/p2_paper_anchor_20261021T065112Z/provenance/reproduction.json).
Two original PNGs and two SVGs rendered through preinstalled system librsvg/Cairo
were visually inspected for labels,axes,actual means and signed cross terms.
This is internal AI-assisted inspection,not human-independent or external
review; cross-environment byte equality is not guaranteed.

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
./scripts/teg p2 verify --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-verify-NEW_ID.json
./scripts/teg p2 summarize --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-rebuild-NEW_ID/summary
./scripts/teg p2 figures --summary /tmp/teg-p2-rebuild-NEW_ID/summary --output /tmp/teg-p2-rebuild-NEW_ID/figures
# Optional future smoke; recorded P1 regression can be reused rather than invoked again.
./scripts/teg p2 smoke --p1-baseline p2_preflight/20261021T063310Z/p1_before.json --reuse-p1-regression-receipt p2_preflight/20261021T063310Z/smoke_01/p1_regression.json --output /tmp/teg-p2-smoke-NEW_ID
# Optional future full, not needed to rebuild existing raw outputs.
./scripts/teg p2 run --config configs/p2_paper_anchor.json --p1-baseline p2_preflight/20261021T063310Z/p1_before.json --output /tmp/teg-p2-full-NEW_ID
```

Use unused output paths. P2 verify requires explicit output and will not overwrite
an existing receipt. The existing wrapper sets PYTHONPATH=src and uses the
recorded Python unless TEG_PYTHON is supplied. [Full reproduction guide](reproduce.md).
Avoid root P1 verify on preserved runs; use the original snapshot with an external
receipt only if separately needed. No such extra P1 verification was run here.

## Local delivery and P3 handoff

All stages remain LOCAL_ONLY. P3 receives documentation/claim review,
clean-environment reproducibility (NOT_RUN here),dependency/metadata review
and a publication-preparation checklist. Remote creation/push/PR/Pages needs
separate user instruction and was not performed. No n/lambda sweep,
non-Gaussian,train/test covariance shift,probit,actual LLM or GPU extension.
GPU/model requests/model downloads/paid API/install-upgrade/remote publication
are all0. Existing unrelated projects/services were not changed or stopped.
MIT applies only to independent project materials; original paper rights and
AI assistance remain explicit in NOTICE. Shared bilingual numbers:
[P2_report_facts.json](P2_report_facts.json). Final handoff is the small UTF-8 TXT
outside the worktree at
`/home/mskim/Codex_main/handoffs/teacher_error_geometry_P2_20261021.txt`.

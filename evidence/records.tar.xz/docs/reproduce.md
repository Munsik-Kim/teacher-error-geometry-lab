# Actual reproduction interfaces

Run from `/home/mskim/Codex_main/teacher-error-geometry-lab`. No install was performed. The executable `scripts/teg` invokes
`python -m teacher_error_geometry` with PYTHONPATH pointing to this project's
src directory. It chooses TEG_PYTHON if supplied, otherwise the existing
`/home/mskim/miniforge3/envs/attention/bin/python`; if that path is absent it
falls back to python3. Dependencies must match requirements.txt.

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
# Existing CPU environment; wrapper sets PYTHONPATH, Agg, local cache, BLAS threads=1.
./scripts/teg verify --run runs/p1_full_20261021_02
./scripts/teg smoke --output /tmp/teg-p0-YOUR_NEW_ID
./scripts/teg summarize --run runs/p1_full_20261021_02 --output /tmp/teg-rebuild-YOUR_NEW_ID/summary
./scripts/teg figures --summary /tmp/teg-rebuild-YOUR_NEW_ID/summary --output /tmp/teg-rebuild-YOUR_NEW_ID/figures
# Optional future full rerun, not needed to inspect/rebuild the saved results.
./scripts/teg run --config configs/p1.json --output /tmp/teg-full-YOUR_NEW_ID
```

Replace YOUR_NEW_ID with an unused suffix. Commands creating outputs fail rather
than overwrite an existing directory. Rebuilding does not fit the full sweep.
The completed recorded rebuild is `reproductions/p1_full_20261021_02_rebuild_01`.
P0 smoke runs17 unit checks, separate independent test-MC and an84-cell20-repeat
pilot, not the full experiment. Normal P1 run is84×2000. Verify checks all raw
records and regenerates12 fixed datasets,32 additional fits. Only the run command
is a full-sweep execution.

Equivalent direct module environment, using an already suitable CPU Python:

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
export PYTHONPATH="$PWD/src"
export MPLCONFIGDIR="$PWD/.cache/matplotlib" MPLBACKEND=Agg
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export BLIS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
/home/mskim/miniforge3/envs/attention/bin/python -m teacher_error_geometry verify --run runs/p1_full_20261021_02
```

These exports affect the current shell and children only, not system services.
The wrapper is preferable because its exports apply only to its process tree.
For quick unit tests only, with those environment settings:

```bash
/home/mskim/miniforge3/envs/attention/bin/python -m unittest discover -s tests -v
```

If no compatible environment is available on another machine, create only a
project-local environment; these are instructions, not actions performed here:

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
TEG_PYTHON="$PWD/.venv/bin/python" ./scripts/teg smoke --output /tmp/teg-venv-smoke-YOUR_NEW_ID
```

SciPy,Torch,Jupyter,GPU frameworks and model downloads are unnecessary.
CPU dependency versions are pinned; bitwise Gaussian samples/plots are verified
in the recorded environment, not guaranteed across arbitrary NumPy/BLAS versions.
BLAS metadata in provenance describes the installed build and thread settings.
Generated CSV uses Python csv.writer's CRLF record endings and Matplotlib SVG
retains path-format spaces. The repository's .gitattributes preserves these
evidence bytes and scopes whitespace lint to their formats; no raw or figure
bytes were normalized after the hash/reproduction checks.

## Immutable recorded versions

Canonical execution commit `df1173e91e77a43a53e9a82beea079c65bd0dab6`,bundle `286b7639b3abfb69503926dad32f35dc27ddd11356a8a15fe2b72377e37716a2`.
Exact execution source is copied under runs/p1_full_20261021_02/provenance/source.
After-run docs and rebuild evidence are excluded from that scientific bundle.
The final delivery commit adds documentation/results without changing that source.
Do not edit a frozen run; use a fresh run ID for scientific/config changes.

The preserved first full run has its old diagnostic classifier and original
INVESTIGATE metadata. To verify it against its own snapshot instead of the
later project's source, use that snapshot as PYTHONPATH and its wrapper:

```bash
bash runs/p1_full_20261021_01/provenance/source/scripts/teg verify --run runs/p1_full_20261021_01 --output /tmp/teg-original-verify-YOUR_NEW_ID.json
```

That old-version verification command is provided for provenance review; the
completed pre-change verification is saved already. A later current-source
verify of that old bundle correctly reports source drift. No extra old-version
verification was run merely to document this command.

## P2 continuation — 2026-10-21, current commands

The P1 commands above are historical guidance. Shared CLI/source has since gained
P2,so root P1 verify would report intentional source drift and its default output
would rewrite the old receipt. Do not run it on preserved P1 evidence. This P2
phase reran the original17 tests once without P1 full/receipt writes. If a later
review needs P1 snapshot verification,retain its output externally and disable
bytecode writes too:

```bash
PYTHONDONTWRITEBYTECODE=1 bash runs/p1_full_20261021_02/provenance/source/scripts/teg verify --run runs/p1_full_20261021_02 --output /tmp/teg-p1-historical-review-NEW_ID.json
```

That historical command is documented,not newly executed here. P2 source and
results are separate; no original P1 receipt is modified.

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
./scripts/teg p2 verify --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-verify-NEW_ID.json
./scripts/teg p2 summarize --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-rebuild-NEW_ID/summary
./scripts/teg p2 figures --summary /tmp/teg-p2-rebuild-NEW_ID/summary --output /tmp/teg-p2-rebuild-NEW_ID/figures
# Optional future smoke; recorded P1 regression can be reused rather than invoked again.
./scripts/teg p2 smoke --p1-baseline p2_preflight/20261021T063310Z/p1_before.json --reuse-p1-regression-receipt p2_preflight/20261021T063310Z/smoke_01/p1_regression.json --output /tmp/teg-p2-smoke-NEW_ID
# Optional future full, not needed to rebuild existing raw outputs.
./scripts/teg p2 run --config configs/p2_paper_anchor.json --p1-baseline p2_preflight/20261021T063310Z/p1_before.json --output /tmp/teg-p2-full-NEW_ID
```


Existing Python and requirements remain as above; no installs/upgrades were
performed. `./scripts/teg p2 --help` and each nested `--help` expose the implemented
interfaces. Smoke can reuse its recorded P1 regression receipt; doing so is
explicitly recorded rather than counted as a new test invocation. Full output
must be a new directory. Full config is configs/p2_paper_anchor.json. Verification
requires a new explicit JSON path. Summary/figures use existing raw and do not fit
new students. Completed external rebuild:
`/home/mskim/Codex_main/teacher-error-geometry-p2-rebuild-20261021T065112Z`.

P2 execution source commit `9b502ee4739e7acb43f94a89bdf57cfbc303a38b`,
bundle `fc3f8e3e43beb117efd16c391d89a0d7b3d103611613d78639c869a01ddd20c7`,config `510781991629e037bd2dc1d66aa4533c7d903b3315b04050a53ee9cca2c1b4ef`.
Full frozen copies: runs/p2_paper_anchor_20261021T065112Z/provenance/source. Same configured environment
reproduces10summary/figure files byte-for-byte. Cross-environment bitwise output
is not guaranteed. The SVG visual previews used preinstalled system librsvg/Cairo
through stdlib ctypes; those libraries are not required for the simulation or
Matplotlib plot export. Clean-environment replay,package-description metadata
refresh and publication preparation remain P3 tasks. No new experiment is implied.

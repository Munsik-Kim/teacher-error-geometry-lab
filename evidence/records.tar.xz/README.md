# Teacher Error Geometry Lab

Local CPU reproduction portfolio: implemented formulas versus risks of actual
repeated OLS fits. [한국어](README.ko.md). **LOCAL_ONLY**; no remote publication.

P1: independent2D special case,84 cells×2000,168000 fits/62000 unique datasets,
17 tests. P2: one original Table1 Gaussian anchor,d5/r3/n27,lambda.45,
20000 shared datasets/80000 fits;12 new tests and one17-test P1 regression PASS.
Both phases have0 failed/missing full rows. P1's340 protected files are unchanged.
[P1 report](docs/P1_REPORT.md) · [P2 report](docs/P2_REPORT.md) ·
[dated history](docs/P2_RUN_HISTORY.md).

| P2 method | Theory | MC mean | MC-SE | z |
| --- | ---: | ---: | ---: | ---: |
| FO | 0.3095238095 | 0.3101549484 | 0.001636764018 | 0.3856016026 |
| FT | 0.4044666667 | 0.4038669197 | 0.001518421967 | -0.3949804327 |
| RO | 0.26 | 0.2598640016 | 0.001152661475 | -0.1179863825 |
| RM | 0.2068751522 | 0.2076789594 | 0.0007907319008 | 1.016535782 |

No >4SE flags in four methods or six paired differences. RM signed sample
cross mean=+.000411069841; it was retained rather than set to its expectation0.

![P2 four original-setting risks](runs/p2_paper_anchor_20261021T065112Z/figures/01_four_methods_truth_risk.png)

Directly mapped [v1 Lemma3.1,Proposition3.2,Proposition4.1,Theorem4.3 and Table1](https://arxiv.org/html/2610.26797v1).
No author code copied. NumPy CPU RNG differs from original PyTorch; this is a
partial expectation reproduction,not the original samples or whole paper.
[Source mapping](docs/P2_SOURCE_MAP.ko.md) · [P2 protocol/schema](docs/P2_PROTOCOL.md).

```bash
cd /home/mskim/Codex_main/teacher-error-geometry-lab
./scripts/teg p2 verify --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-verify-NEW_ID.json
./scripts/teg p2 summarize --run runs/p2_paper_anchor_20261021T065112Z --output /tmp/teg-p2-rebuild-NEW_ID/summary
./scripts/teg p2 figures --summary /tmp/teg-p2-rebuild-NEW_ID/summary --output /tmp/teg-p2-rebuild-NEW_ID/figures
```

Outputs must be new. Wrapper supplies PYTHONPATH=src,Agg,project cache and
child BLAS threads1; default existing attention Python or TEG_PYTHON.
[All commands/dependencies and P1 preservation](docs/reproduce.md).
P2 full runner5.903s; [freeze/source/config hashes](runs/p2_paper_anchor_20261021T065112Z/provenance/freeze.json).
P1 reports and old commands are historical; do not overwrite their receipts.

P3 documentation/clean-environment/publication preparation is pending. No
n/lambda sweep,non-Gaussian,correlation shift,probit,actual LLM or CFPB claim.
GPU/model/download/paidAPI/install-upgrade/remote publication0. AI-assisted
internal checks,not independent human review. MIT covers independent project
materials; source-paper/third-party rights remain separate in [NOTICE](NOTICE).
